-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 07, 2013 at 12:07 PM
-- Server version: 5.1.30
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `avail`
--

CREATE TABLE IF NOT EXISTS `avail` (
  `model` varchar(20) NOT NULL,
  `no_days` varchar(10) NOT NULL,
  `no_products` int(11) NOT NULL,
  PRIMARY KEY (`model`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `avail`
--

INSERT INTO `avail` (`model`, `no_days`, `no_products`) VALUES
('a234', '2-4 days', 4),
('9300', '2-4 days', 4),
('X111', '2-4 days', 3),
('XT910', '2-4 days', 4),
('miro', '2-4 days', 5),
('S3', '2-4 days', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `model` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phno` bigint(10) NOT NULL,
  `order_status` varchar(50) NOT NULL DEFAULT 'Not processed',
  PRIMARY KEY (`id`,`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `email`, `fname`, `lname`, `dob`, `model`, `address`, `phno`, `order_status`) VALUES
(21, 'boscoferns@gmail.com', 'bosco', 'ferns', '2012-12-19', 'XT910', 'bosco''s home', 11111111, 'Not processed'),
(20, 'dssggs@gmail.com', 'Dipesh', 'Naik', '2012-11-19', 'S3', 'my house', 7777777777777, 'Pending'),
(19, 'brandondsz26@gmail.com', 'brandon', 'dsouza', '2012-11-18', 'a234', 'Quadros apt margao,goa', 9421744476, 'Delivered');

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE IF NOT EXISTS `features` (
  `model` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `brand` varchar(10) NOT NULL,
  `os` varchar(20) NOT NULL,
  `processor` varchar(10) NOT NULL,
  `ram` varchar(10) NOT NULL,
  `intrnl_m` varchar(10) NOT NULL,
  `extrnl_m` varchar(10) NOT NULL,
  `scrn_size` varchar(10) NOT NULL,
  `scrn_res` varchar(10) NOT NULL,
  `camera` varchar(10) NOT NULL,
  `bdy_type` varchar(10) NOT NULL,
  `gps` varchar(10) NOT NULL,
  `bluetooth` varchar(10) NOT NULL,
  `wifi` varchar(10) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  PRIMARY KEY (`model`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`model`, `name`, `brand`, `os`, `processor`, `ram`, `intrnl_m`, `extrnl_m`, `scrn_size`, `scrn_res`, `camera`, `bdy_type`, `gps`, `bluetooth`, `wifi`, `price`, `image`) VALUES
('a234', 'Explorer', 'htc', 'android_2.3', '600MHz', '512MB', '90MB', 'upto 32GB', '3.2 inch', '320X480', '3MP', 'bar', 'A-GPS', 'v2.1', '802.11 b/g', 8199, 'images/htcexplorer.jpeg'),
('9300', 'Curve', 'blackberry', 'Blackberry_OS', '800MHz', '256Mb', '2GB', 'upto 32GB', '2.4inch', '240X340', '2MP', 'bar', 'A-GPS', 'v2.1', '802.11 b/g', 10299, 'images/blackberrycurve.jpeg'),
('X111', 'One X', 'htc', 'android_4.0', '1.5GHz', '1 GB', '16GB', '0', '4.7 inch', '1280X720', '8MP', 'bar', 'A-GPS', 'v4', '802.11 b/g', 35000, 'images/htconex.jpeg'),
('XT910', 'RAZR', 'motorola', 'android_2.3', '1.2Ghz', '1GB', '16GB', 'upto 32GB', '4.3 inch', '960X540', '8MP', 'bar', 'A-GPS', 'v3', '802.11 b/g', 21999, 'images/motorolarazr.jpeg'),
('miro', 'Xperia miro', 'sony', 'android_4.0', '800Mhz', '512MB', '4GB', 'upto 32GB', '3.5 inch', '320X480', '5MP', 'bar', 'A-GPS', 'v3', '802.11 b/g', 15000, 'images/sonyxperiamiro.jpeg'),
('S3', 'Galaxy S3', 'samsung', 'android_4.0', '1.4GHz', '1GB', '16GB', 'upto 64GB', '4.8 inch', '720X1280', '8MP', 'bar', 'A-GPS', 'v4', '802.11 b/g', 34900, 'images/samsungs3.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `user` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user`, `password`) VALUES
('admin', 'admin'),
('brandon', 'brandon'),
('yellow', 'smmr'),
('jj', 'smthng');

-- --------------------------------------------------------

--
-- Table structure for table `spl_features`
--

CREATE TABLE IF NOT EXISTS `spl_features` (
  `model` varchar(20) NOT NULL,
  `features` varchar(100) NOT NULL,
  PRIMARY KEY (`model`,`features`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `spl_features`
--

INSERT INTO `spl_features` (`model`, `features`) VALUES
('9300', 'blackberry messenger'),
('a234', 'ambient light sensor'),
('miro', 'auto-focus'),
('S3', 'HD video recording, AMOLED display'),
('X111', 'auto-focus,dedicated image chip'),
('XT910', 'HD video recording, AMOLED display');
